<?php get_header(); ?>
<div class="container">
    <div class="row p-3">
        <div class="col-6 m-auto">
        <h3> <?php the_title(); ?> </h3> 
            </p><?php the_content(); ?>
        </div>
</div>
</div>
<div class="container">
    <div class="row">
        <div class="col-3 pl-0 pr-0 mx-0">
        
<img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img1.jpeg" alt="image">
        </div>
        <div class="col-3 pl-0 pr-0 mx-0">
        
<img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img9.jpg" alt="image">
        </div>
        <div class="col-3 px-0 mx-0">
        <img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img2.jpeg" alt="image">
        </div>
        <div class="col-3 pl-0 pr-0 mx-0">
        
<img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img10.jpg" alt="image">
        </div>
        <div class="col-3 mx-0 px-0">
        <img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img3.jpeg" alt="image">
        </div>
        <div class="col-3 pl-0 pr-0 mx-0">
        
<img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img11.jpg" alt="image">
        </div>
        <div class="col-3 mx-0 px-0 my-0">
        <img class="img w-100 " src="<?php echo get_template_directory_uri(); ?>/images/img4.jpg" alt="image">
        
        </div>
        <div class="col-3 mx-0 px-0">
        <img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img5.jpg" alt="image">
        
        </div>
        <div class="col-3 mx-0 px-0 my-0 py-0">
        <img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img6.jpg" alt="image">
        </div>
        <div class="col-3 mx-0 px-0 my-0 py-0">
        <img class="img w-100 " src="<?php echo get_template_directory_uri(); ?>/images/img7.jpg" alt="image">
        
        </div>
        <div class="col-3 mx-0 px-0 py-0 my-0">
        <img class="img w-100" src="<?php echo get_template_directory_uri(); ?>/images/img8.jpg" alt="image">
        
        </div>
        <div class="col-3 pl-0 pr-0 mx-0">
        
<img class="img " src="<?php echo get_template_directory_uri(); ?>/images/img12.jpg" alt="image">
        </div>
    </row>
</div>

<?php get_footer(); ?>