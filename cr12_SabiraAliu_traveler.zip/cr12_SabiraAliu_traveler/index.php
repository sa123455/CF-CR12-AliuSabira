
  <?php get_header(); ?>

   <div class="container">
   <hr>
       <div id="text-pink" class="row justify-content-center  p-3">
          
     <h3 class="text-white font-italic">The Adventure begins here...</h3>
    
   </div>
   <hr>
   

   <div class="container">
       <div class="row">

      

       <?php if(have_posts()) : ?> <!--  If there are posts available  -->
       
         <!-- if there are posts, iterate the posts in the loop-->
         <?php while(have_posts()) : the_post(); ?>
         <div class="col-4 ">
         <?php if(has_post_thumbnail()) : ?>
       <?php the_post_thumbnail('medium'); ?>
       <?php endif; ?>
         <a class="title" href="<?php the_permalink(); ?>"><!--retrieves URL for the permalink-->
         <h3> <?php the_title(); ?> </h3>   <!--retrieves blog title-->
          </a>
          <small><?php the_time('F j, Y g:i a'); ?></small><!--retrieves date blog entry was created-->
          <p class="text-primary"> <?php the_author(); ?></p><!--retrieves author of blog entry-->
          
          </p><?php the_excerpt(); ?><!--retrieves content--></p>
          </div>
           <?php endwhile; ?><!--end the while loop-->
          
         
            <?php else :?> <!-- if no posts are found then: -->
    <p>No posts found</p>  <!-- no posts found displayed -->
    
       </div>
       </div>
       <div>
       <?php endif; ?> <!-- end if -->
            </div>
      
      
       
       
   
   
       
       
  


   
   <?php get_footer(); ?>
  