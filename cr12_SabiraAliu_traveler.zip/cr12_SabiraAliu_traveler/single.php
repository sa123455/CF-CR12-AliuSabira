<?php get_header(); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col">
            <div>
            <?php if(has_post_thumbnail()) : ?>
       <?php the_post_thumbnail(array(300, 300)); ?>
       <?php endif; ?> 
            </div>
        <h3 class="text-secondary"> <?php the_title(); ?> </h3>
        <small><?php the_time('F j, Y g:i a'); ?></small><!--retrieves date blog entry was created-->
        <p><?php the_content(); ?></p>
        </div>
</div>
</div>
<div class="container">
    <div class="row">
        <div class="col-6 m-auto">
<div> <?php comments_template(); ?> </div>
            </div>
            </div>
            </div>
<?php get_footer(); ?>